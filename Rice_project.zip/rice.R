library("read.csv")
library("ggplot2")

data <- read.csv("/project/skresov/tillers/vgupte/Rice_project/Rice_GRIN-Global.csv")

ggplot(data, aes(y = AMYLOSE)) +
  geom_boxplot(fill = "lightgreen", color = "black") +
  theme_minimal(base_size = 13) +
  labs(title = "Amylose", y = "Amylose Content")
ggsave("boxplot_amylose.pdf", p, width = 8, height = 6, dpi = 300)

ggscatter(data, x = "AMYLOSE", y = "SALT TOLERANCE",
          add = "reg.line", conf.int = TRUE, color = "darkorange",
          cor.coef = TRUE, cor.method = "pearson",
          xlab = "Amylose Content", ylab = "Salt Tolerance") +
  theme_minimal() +
  theme(panel.border = element_rect(color = "black", fill = NA, size = 1))
ggsave("scatterplot", p, width = 8, height = 6, dpi = 299)





