library(ggplot2)

data5 <- read.csv("Rice_GRIN-Global.csv")
data5$KERNEL.LENGTH.WIDTH.RATIO <- as.numeric(data5$KERNEL.LENGTH.WIDTH.RATIO)
p2 <- ggplot(data5, aes(x = ACCESSION, y = KERNEL.LENGTH.WIDTH.RATIO)) +
  
  geom_bar(stat = "identity", fill = "darkgreen") +
  
  theme_minimal() +
  
  theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1)) +
  
  labs(title = "Kernel Length/Width Ratio by Rice Accession",
       
       x = "Accession",
       
       
print(p2)

p1 <- ggplot(data5, aes(x = ACCESSION, y = KERNEL.LENGTH.WIDTH.RATIO)) +
  geom_point(color = "darkgreen", size = 1) +
  theme_minimal() +
  theme(axis.text.x = element_blank(),  # hide crowded labels
        axis.ticks.x = element_blank()) +
  labs(title = "Kernel L/W Ratio by Accession",
       x = "Accession", y = "Kernel L/W Ratio")
print(p1)
ggsave("kernel_boxplot.png", plot = p1, width = 8, height = 5)
