library(ggplot2)
data5 <- read.csv("Rice_GRIN-Global.csv")
p1 <- ggplot(data5, aes(x = ACCESSION, y = AMYLOSE)) +
  geom_bar(stat = "identity", fill = "steelblue") +
  theme_minimal() +
  theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1)) +
  labs(title = "Amylose Content by Rice Accession",
       x = "Accession",
       y = "Amylose (%)")
ggsave("amylose_boxplot.png", plot = p1, width = 8, height = 5)

p2 <- ggplot(data5, aes(x = ACCESSION, y = KERNEL.LENGTH.WIDTH.RATIO)) +
  geom_bar(stat = "identity", fill = "darkgreen") +
  theme_minimal() +
  theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1)) +
  labs(title = "Kernel Length/Width Ratio by Rice Accession",
       x = "Accession",
       y = "Kernel L/W Ratio")
ggsave("Kernel_boxplot.png", plot = p2, width = 8, height = 5)


p3 <- ggplot(data5, aes(x = AMYLOSE, y = KERNEL.LENGTH.WIDTH.RATIO)) +
  geom_point(alpha = 0.4, color = "darkblue") +
  theme_minimal() +
  labs(title = "Amylose vs. Kernel Length/Width Ratio",
       x = "Amylose (%)",
       y = "Kernel L/W Ratio")
ggsave("amylose_kernel_boxplot.png", plot = p3, width = 8, height = 5)
data5$KERNEL.LENGTH.WIDTH.RATIO <- as.numeric(data5$KERNEL.LENGTH.WIDTH.RATIO)

p4 <- ggplot(data5, aes(x = KERNEL.LENGTH.WIDTH.RATIO)) +
  geom_histogram(binwidth = 0.2, fill = "darkgreen", color = "black") +
  theme_minimal() +
  labs(title = "Distribution of Kernel Length/Width Ratio",
       x = "Kernel L/W Ratio",
       y = "Count")
ggsave("Kernel_histogram.png", plot = p4, width = 8, height = 5)

